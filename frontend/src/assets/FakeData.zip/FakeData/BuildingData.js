import React from 'react';
import Biligates from "../../assets/images/building/BiligatesPhoto.jpeg";
import Rtb from "../../assets/images/building/Rtb.jpeg";
import Cotton from "../../assets/images/building/cotton.jpeg";
import Kl from "../../assets/images/building/Klrao.jpeg";
import Newton from "../../assets/images/building/Newton.jpeg";
import Thub from "../../assets/images/building/Thub.jpeg";

const buildingsData = [
    {
        sno: 1,
        buildingName: 'Ratan Tata Bhavan',
        image: Rtb,
        buildingInCharge: 'Vinay',
        buildingLocation: ["82.066512", "17.088359"],
        buildingId: 'RTB'
    },
    {
        sno: 2,
        buildingName: 'Billigates Bhavan',
        image: Biligates,
        buildingInCharge: 'Vinay',
        buildingLocation: ["82.0672205", "17.0891659"],
        buildingId: 'BGB'
    },
    {
        sno: 3,
        buildingName: 'Cotton Bhavan',
        image: Cotton,
        buildingInCharge: 'Vinay',
        buildingLocation: ["82.0671344", "17.0882378"],
        buildingId: 'CTB'
    },
    {
        sno: 4,
        buildingName: 'KL Rao Bhavan',
        image:Kl,
        buildingInCharge: 'Vinay',
        buildingLocation: ["82.067102", "17.088880"],
        buildingId: 'KLRB'
    },
    {
        sno: 5,
        buildingName: 'Newton Bhavan',
        image: Newton,
        buildingInCharge: 'Vinay',
        buildingLocation: ["82.0720321", "17.0889013"],
        buildingId: 'NB'
    },
    {
        sno: 6,
        buildingName: 'Technical Hub',
        image: Thub,
        buildingInCharge: 'Dinesh',
        buildingLocation: ["82.0698295", "17.0878153"],
        buildingId: 'THUB'
    },
];

export default buildingsData;
