import React from 'react';

const HallData = [
    {
        sno: 1,
        buildingName: 'Ratan Tata Bhavan',
        buildingId: "RTB",
        floorName: '1',
        floorId: 'RTBF1',
        hallName: 101,
        hallId: 'RTBF1101'
    },
    {
        sno: 2,
        buildingName: 'Ratan Tata Bhavan',
        buildingId: "RTB",
        floorName: '1',
        floorId: 'RTBF1',
        hallName: 102,
        hallId: 'RTBF1102'
    },
    {
        sno: 3,
        buildingName: 'Ratan Tata Bhavan',
        buildingId: "RTB",
        floorName: '1',
        floorId: 'RTBF1',
        hallName: 103,
        hallId: 'RTBF1103'
    },
    {
        sno: 4,
        buildingName: 'Ratan Tata Bhavan',
        buildingId: "RTB",
        floorName: '1',
        floorId: 'RTBF1',
        hallName: 104,
        hallId: 'RTBF1104'
    },
    {
        sno: 5,
        buildingName: 'Biligates Bhavan',
        buildingId: "BGB",
        floorName: '1',
        floorId: 'BGBF1',
        hallName: '101',
        hallId: 'RTBF1101'
    },
    {
        sno: 6,
        buildingName: 'Biligates Bhavan',
        buildingId: "BGB",
        floorName: '1',
        floorId: 'BGBF1',
        hallName: '102',
        hallId: 'RTBF1102'
    },
    {
        sno: 7,
        buildingName: 'Biligates Bhavan',
        buildingId: "BGB",
        floorName: '1',
        floorId: 'BGBF1',
        hallName: '103',
        hallId: 'RTBF1103'
    },
    {
        sno: 8,
        buildingName: 'Biligates Bhavan',
        buildingId: "BGB",
        floorName: '1',
        floorId: 'BGBF1',
        hallName: '104',
        hallId: 'RTBF1104'
    },
    {
        sno: 9,
        buildingName: 'Cotton Bhavan',
        buildingId: "CB",
        floorName: '1',
        floorId: 'CBF1',
        hallName: '101',
        hallId: 'RTBF1101'
    },
    {
        sno: 10,
        buildingName: 'Cotton Bhavan',
        buildingId: "CB",
        floorName: '1',
        floorId: 'CBF1',
        hallName: '102',
        hallId: 'RTBF1102'
    },
    {
        sno: 11,
        buildingName: 'Cotton Bhavan',
        buildingId: "CB",
        floorName: '1',
        floorId: 'CBF1',
        hallName: '103',
        hallId: 'RTBF1103'
    },
    {
        sno: 12,
        buildingName: 'Cotton Bhavan',
        buildingId: "CB",
        floorName: '1',
        floorId: 'CBF1',
        hallName: '104',
        hallId: 'RTBF1104'
    },
    {
        sno: 13,
        buildingName: 'Technical Hub',
        buildingId: "THUB",
        floorName: '1.1',
        floorId: 'THUBF1H1',
        hallName: 'H1',
        hallId: 'THUBF1H1'
    },{
        sno:14,
        buildingName: 'Technical Hub',
        buildingId: "THUB",
        floorName: '1.2',
        floorId: 'THUBF1H2',
        hallName: 'H2',
        hallId: 'THUBF1H2'
    }
    ,{
        sno:15,
        buildingName: 'Technical Hub',
        buildingId: "THUB",
        floorName: '2.1',
        floorId: 'THUBF2H1',
        hallName: 'H1',
        hallId: 'THUBF2H1'
    },{
        sno:16,
        buildingName: 'Technical Hub',
        buildingId: "THUB",
        floorName: '2.2',
        floorId: 'THUBF2H2',
        hallName: 'H2',
        hallId: 'THUBF2H2'
    },
    {
        sno: 17,
        buildingName: 'Technical Hub',
        buildingId: "THUB",
        floorName: '3.1',
        floorId: 'THUBF3H1',
        hallName: 'B1',
        hallId: 'THUBF3B1'
    },{
        sno:18,
        buildingName: 'Technical Hub',
        buildingId: "THUB",
        floorName: '3.2',
        floorId: 'THUBF3H2',
        hallName: 'B2',
        hallId: 'THUBF3B2'
    }
    ,{
        sno:18,
        buildingName: 'Technical Hub',
        buildingId: "THUB",
        floorName: '3.3',
        floorId: 'THUBF3H2',
        hallName: 'B3',
        hallId: 'THUBF3B3'

    }
    ,{
        sno:19,
        buildingName: 'Technical Hub',
        buildingId: "THUB",
        floorName: '3.4',
        floorId: 'THUBF3H1',
        hallName: 'B4',
        hallId: 'THUBF4B4'
    }
    ,
    {
        sno:15,
        buildingName: 'Technical Hub',
        buildingId: "THUB",
        floorName: '4.1',
        floorId: 'THUBF4H1',
        hallName: 'H1',
        hallId: 'THUBF4H1'
    },{
        sno:16,
        buildingName: 'Technical Hub',
        buildingId: "THUB",
        floorName: '4.2',
        floorId: 'THUBF4H2',
        hallName: 'H2',
        hallId: 'THUBF4H2'
    }

];
export default HallData;
